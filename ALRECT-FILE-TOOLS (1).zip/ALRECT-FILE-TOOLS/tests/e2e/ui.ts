import type { Browser } from 'playwright';

export interface UiCheck { name: string; problems: string[] }

/** Page-level checks that are not tied to one tool: theme switch, persistence, keyboard, layout, reduced motion. */
export async function runUiChecks(browser: Browser, base: string): Promise<UiCheck[]> {
  const out: UiCheck[] = [];
  const check = async (name: string, fn: () => Promise<string[]>) => {
    try { out.push({ name, problems: await fn() }); } catch (e) { out.push({ name, problems: [`threw: ${(e as Error).message}`] }); }
  };
  const theme = (p: import('playwright').Page) => p.evaluate(() => document.documentElement.dataset.theme);
  const bg = (p: import('playwright').Page) => p.evaluate(() => getComputedStyle(document.querySelector('.card') as Element).backgroundColor);

  await check('theme: first visit follows the clock (06-18 day)', async () => {
    const res: string[] = [];
    for (const [hour, want] of [[9, 'day'], [22, 'night']] as const) {
      const ctx = await browser.newContext({ timezoneId: 'UTC' });
      await ctx.clock.setFixedTime(new Date(Date.UTC(2026, 0, 1, hour, 0, 0)));
      const p = await ctx.newPage(); await p.goto(`${base}#/tools`); await p.waitForSelector('.theme-switch');
      const t = await theme(p); if (t !== want) res.push(`at ${hour}:00 expected ${want}, got ${t}`);
      await ctx.close();
    }
    return res;
  });

  await check('theme: click toggles, colours change, choice survives reload', async () => {
    const ctx = await browser.newContext(); await ctx.addInitScript(() => { if (!localStorage.getItem('alrect.seeded')) { localStorage.setItem('alrect.seeded', '1'); localStorage.setItem('alrect.theme', 'day'); } });
    const p = await ctx.newPage(); await p.goto(`${base}#/tools`); await p.waitForSelector('.card');
    const res: string[] = [];
    const dayBg = await bg(p);
    await p.click('.theme-switch'); await p.waitForTimeout(300);
    if ((await theme(p)) !== 'night') res.push('click did not switch to night');
    if (!(await p.isChecked('.theme-switch__checkbox'))) res.push('checkbox not checked in night');
    const nightBg = await bg(p); if (nightBg === dayBg) res.push(`card colour unchanged (${dayBg})`);
    await p.reload(); await p.waitForSelector('.card');
    if ((await theme(p)) !== 'night') res.push('night not remembered after reload');
    await p.click('.theme-switch'); await p.waitForTimeout(200);
    if ((await theme(p)) !== 'day') res.push('second click did not return to day');
    await ctx.close(); return res;
  });

  await check('theme: keyboard (focus + Space) toggles the switch', async () => {
    const ctx = await browser.newContext(); await ctx.addInitScript(() => { if (!localStorage.getItem('alrect.seeded')) { localStorage.setItem('alrect.seeded', '1'); localStorage.setItem('alrect.theme', 'day'); } });
    const p = await ctx.newPage(); await p.goto(`${base}#/tools`); await p.waitForSelector('.theme-switch');
    await p.focus('.theme-switch__checkbox'); await p.keyboard.press('Space'); await p.waitForTimeout(200);
    const res: string[] = []; if ((await theme(p)) !== 'night') res.push('Space did not toggle');
    if ((await p.getAttribute('.theme-switch__checkbox', 'aria-label')) !== 'Night mode') res.push('missing aria-label');
    await ctx.close(); return res;
  });

  await check('layout: no horizontal scroll at 390px in day and night', async () => {
    const res: string[] = [];
    for (const t of ['day', 'night']) {
      const ctx = await browser.newContext({ viewport: { width: 390, height: 800 } }); await ctx.addInitScript((v) => localStorage.setItem('alrect.theme', v), t);
      const p = await ctx.newPage();
      for (const route of ['#/', '#/tools', '#/tool/json-to-csv']) {
        await p.goto(base + route); await p.waitForTimeout(500);
        if (await p.evaluate(() => document.documentElement.scrollWidth > innerWidth)) res.push(`${t} ${route} scrolls horizontally`);
      }
      await ctx.close();
    }
    return res;
  });

  await check('motion: reduced-motion disables the night card tilt', async () => {
    const ctx = await browser.newContext({ reducedMotion: 'reduce' }); await ctx.addInitScript(() => localStorage.setItem('alrect.theme', 'night'));
    const p = await ctx.newPage(); await p.goto(`${base}#/tools`); await p.waitForSelector('.card');
    await p.hover('.card'); await p.waitForTimeout(300);
    const tr = await p.evaluate(() => getComputedStyle(document.querySelector('.card') as Element).transform);
    await ctx.close(); return tr === 'none' ? [] : [`card transform under reduced motion: ${tr}`];
  });

  await check('donate: tab, safe external link, page renders', async () => {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 800 } });
    const p = await ctx.newPage(); await p.goto(`${base}#/tools`); await p.waitForSelector('.nav');
    const res: string[] = [];
    if (!(await p.isVisible('.nav a:has-text("Donate")'))) res.push('Donate tab not visible at 390px');
    await p.click('.nav a:has-text("Donate")'); await p.waitForSelector('.donate-btn');
    const a = await p.evaluate(() => { const e = document.querySelector('.donate-btn') as HTMLAnchorElement; return { href: e.href, target: e.target, rel: e.rel, label: e.getAttribute('aria-label') ?? '' }; });
    if (a.href !== 'https://saweria.co/alzhenjb') res.push(`href is ${a.href}`);
    if (a.target !== '_blank') res.push('target is not _blank');
    if (!/noopener/.test(a.rel) || !/noreferrer/.test(a.rel)) res.push(`rel is "${a.rel}"`);
    if (!/Donation for request features/.test(a.label)) res.push(`aria-label is "${a.label}"`);
    if (await p.evaluate(() => document.documentElement.scrollWidth > innerWidth)) res.push('donate page scrolls horizontally');
    await ctx.close(); return res;
  });

  await check('credits: five contact links with the right targets, no overflow at 390px', async () => {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 800 } });
    const p = await ctx.newPage(); await p.goto(`${base}#/about`); await p.waitForSelector('.doodle-container');
    const res: string[] = [];
    const want = ['mailto:alrectofficial@gmail.com', 'https://github.com/alrxf-dev', 'https://www.instagram.com/alrectdev8', 'https://www.tiktok.com/@xploitalip', 'https://wa.me/6282192401340'];
    const got = await p.evaluate(() => [...document.querySelectorAll('.doodle-link')].map((a) => { const e = a as HTMLAnchorElement; return { href: e.getAttribute('href') ?? '', target: e.target, rel: e.rel }; }));
    if (JSON.stringify(got.map((g) => g.href)) !== JSON.stringify(want)) res.push(`hrefs: ${got.map((g) => g.href).join(', ')}`);
    for (const g of got.filter((x) => x.href.startsWith('http'))) if (g.target !== '_blank' || !/noopener/.test(g.rel)) res.push(`unsafe external link ${g.href}`);
    const text = await p.locator('.credit-list').innerText();
    for (const t of ['alrectofficial@gmail.com', 'alrxf-dev', '@alrectdev8', '@xploitalip', '+62 821-9240-1340']) if (!text.includes(t)) res.push(`text list missing ${t}`);
    if (await p.evaluate(() => document.documentElement.scrollWidth > innerWidth)) res.push('about page scrolls horizontally');
    await ctx.close(); return res;
  });

  await check('new: badge on the card and tool page, New filter lists only new tools', async () => {
    const ctx = await browser.newContext({ viewport: { width: 1100, height: 800 } });
    const p = await ctx.newPage(); await p.goto(`${base}#/tools`); await p.waitForSelector('.card');
    const res: string[] = [];
    const total = await p.locator('.card').count();
    await p.getByRole('button', { name: 'New', exact: true }).click(); await p.waitForTimeout(300);
    const shown = await p.locator('.card').count();
    if (shown < 1 || shown >= total) res.push(`New filter shows ${shown} of ${total} cards`);
    if (!(await p.locator('.card h3', { hasText: 'Video Watermark' }).count())) res.push('Video Watermark missing under New');
    if ((await p.locator('.card .badge-new').count()) !== shown) res.push('every card under New should carry the NEW badge');
    if (!/new=1/.test(p.url())) res.push(`URL does not record the filter: ${p.url()}`);
    await p.goto(`${base}#/tool/video-watermark`); await p.waitForSelector('.tool-head');
    if (!(await p.locator('.tool-meta .badge-new').count())) res.push('tool page has no NEW badge');
    await ctx.close(); return res;
  });

  await check('watermark tool: no horizontal scroll at 390px with a video and a logo loaded (day and night)', async () => {
    const res: string[] = [];
    const fs = await import('node:fs'); const path = await import('node:path'); const { fileURLToPath } = await import('node:url');
    const fx = (n: string) => fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'fixtures', n));
    for (const t of ['day', 'night']) {
      const ctx = await browser.newContext({ viewport: { width: 390, height: 900 } }); await ctx.addInitScript((v) => localStorage.setItem('alrect.theme', v), t);
      const p = await ctx.newPage(); await p.goto(`${base}#/tool/video-watermark`); await p.waitForSelector('.tool-panel input[type=file]');
      await p.locator('.tool-panel input[type=file]').nth(0).setInputFiles({ name: 'clip.webm', mimeType: 'video/webm', buffer: fx('clip.webm') });
      await p.waitForSelector('.wm-canvas');
      await p.locator('.tool-panel input[type=file]').nth(1).setInputFiles({ name: 'logo_red.png', mimeType: 'image/png', buffer: fx('logo_red.png') });
      await p.waitForTimeout(600);
      if (await p.evaluate(() => document.documentElement.scrollWidth > innerWidth)) res.push(`${t}: page scrolls horizontally`);
      const nameW = await p.evaluate(() => (document.querySelector('.file-list .name') as HTMLElement | null)?.getBoundingClientRect().width ?? 0);
      if (nameW < 60) res.push(`${t}: file name column is only ${Math.round(nameW)}px wide`);
      await ctx.close();
    }
    return res;
  });
  return out;
}
